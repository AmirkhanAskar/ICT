a = int(input())
b = int(input())
c = int(input())

arr = []
arr.append(a)
arr.append(b)
arr.append(c)

arr.sort()
print(arr[0], arr[1], arr[2])